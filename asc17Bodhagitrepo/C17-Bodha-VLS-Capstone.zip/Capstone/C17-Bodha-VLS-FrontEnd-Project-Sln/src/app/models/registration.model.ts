export interface Registration {
  id: string; // Auto-generated ID (e.g., "R0001")
  courseId: string; // Course ID
  learnerId: string; // Learner ID
}
